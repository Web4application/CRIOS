# Kubu-Hai Project

Full-stack boilerplate with Next.js frontend, FastAPI backend, Node bot, PostgreSQL, Redis, and Docker.